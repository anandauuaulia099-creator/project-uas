<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'

import UserAvatar from '@/components/UserAvatar.vue'
import { getUser, updateUser } from '@/services/userApi'

const route = useRoute()
const router = useRouter()
const form = reactive({ name: '', email: '', avatar: '' })
const errors = reactive({ name: '', email: '', avatar: '' })
const isLoading = ref(true)
const isSubmitting = ref(false)
const loadError = ref('')
const submitError = ref('')
const previewName = computed(() => form.name.trim() || 'Nama pengguna')

function validateForm() {
  errors.name = ''
  errors.email = ''
  errors.avatar = ''

  if (!form.name.trim()) errors.name = 'Nama lengkap wajib diisi.'
  else if (form.name.trim().length < 3) errors.name = 'Nama minimal terdiri dari 3 karakter.'
  if (!form.email.trim()) errors.email = 'Alamat email wajib diisi.'
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errors.email = 'Masukkan alamat email yang valid.'
  if (form.avatar && !/^https?:\/\/.+/i.test(form.avatar)) errors.avatar = 'URL foto harus diawali dengan http:// atau https://.'

  return !errors.name && !errors.email && !errors.avatar
}

async function loadUser() {
  try {
    const user = await getUser(route.params.id)
    form.name = user.name ?? ''
    form.email = user.email ?? ''
    form.avatar = user.avatar ?? ''
  } catch (error) {
    loadError.value = 'Data pengguna tidak dapat dimuat. Silakan coba lagi.'
    console.error(error)
  } finally {
    isLoading.value = false
  }
}

async function handleSubmit() {
  submitError.value = ''
  if (!validateForm()) return
  isSubmitting.value = true
  try {
    await updateUser(route.params.id, {
      name: form.name.trim(),
      email: form.email.trim().toLowerCase(),
      avatar: form.avatar.trim(),
    })
    await router.push({ name: 'users', query: { updated: '1' } })
  } catch (error) {
    submitError.value = 'Perubahan gagal disimpan. Periksa koneksi internet lalu coba kembali.'
    console.error(error)
  } finally {
    isSubmitting.value = false
  }
}

onMounted(loadUser)
</script>

<template>
  <section>
    <RouterLink to="/" class="focus-ring mb-6 inline-flex items-center gap-2 rounded-lg text-sm font-bold text-slate-500 transition hover:text-ink">
      <span aria-hidden="true">←</span> Kembali ke daftar
    </RouterLink>

    <div v-if="isLoading" class="page-card mx-auto max-w-2xl animate-pulse p-8" aria-live="polite">
      <div class="h-8 w-56 rounded bg-slate-100"></div>
      <div class="mt-8 grid gap-6"><div v-for="i in 3" :key="i" class="h-12 rounded-xl bg-slate-100"></div></div>
    </div>

    <div v-else-if="loadError" class="page-card mx-auto max-w-2xl p-8 text-center" role="alert">
      <p class="font-bold text-red-600">{{ loadError }}</p>
      <button class="btn-secondary mt-5" type="button" @click="isLoading = true; loadError = ''; loadUser()">Coba lagi</button>
    </div>

    <div v-else class="grid gap-8 lg:grid-cols-[minmax(0,1fr)_340px] lg:items-start">
      <div>
        <div class="mb-8"><div class="mb-3 inline-flex rounded-full bg-blue-50 px-3 py-1 text-xs font-bold uppercase tracking-wider text-blue-700">Perbarui data</div><h1 class="text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">Edit Pengguna</h1><p class="mt-2 text-sm leading-6 text-slate-500 sm:text-base">Perbarui informasi pengguna yang dipilih.</p></div>
        <form class="page-card p-5 sm:p-8" novalidate @submit.prevent="handleSubmit">
          <div v-if="submitError" class="mb-6 rounded-xl border border-red-100 bg-red-50 p-4 text-sm text-red-700" role="alert">{{ submitError }}</div>
          <div class="grid gap-6">
            <div><label for="edit-name" class="mb-2 block text-sm font-bold text-ink">Nama lengkap <span class="text-red-500">*</span></label><input id="edit-name" v-model="form.name" class="form-input" :class="{ '!border-red-300': errors.name }" autocomplete="name" @input="errors.name = ''" /><p v-if="errors.name" class="mt-2 text-xs font-medium text-red-600">{{ errors.name }}</p></div>
            <div><label for="edit-email" class="mb-2 block text-sm font-bold text-ink">Alamat email <span class="text-red-500">*</span></label><input id="edit-email" v-model="form.email" type="email" class="form-input" :class="{ '!border-red-300': errors.email }" autocomplete="email" @input="errors.email = ''" /><p v-if="errors.email" class="mt-2 text-xs font-medium text-red-600">{{ errors.email }}</p></div>
            <div><div class="mb-2 flex justify-between"><label for="edit-avatar" class="text-sm font-bold text-ink">URL foto profil</label><span class="text-xs text-slate-400">Opsional</span></div><input id="edit-avatar" v-model="form.avatar" type="url" class="form-input" :class="{ '!border-red-300': errors.avatar }" @input="errors.avatar = ''" /><p v-if="errors.avatar" class="mt-2 text-xs font-medium text-red-600">{{ errors.avatar }}</p></div>
          </div>
          <div class="mt-8 flex flex-col-reverse gap-3 border-t border-slate-100 pt-6 sm:flex-row sm:justify-end"><RouterLink to="/" class="btn-secondary">Batal</RouterLink><button class="btn-primary min-w-40" type="submit" :disabled="isSubmitting">{{ isSubmitting ? 'Menyimpan...' : 'Simpan perubahan' }}</button></div>
        </form>
      </div>
      <aside class="page-card p-6 text-center lg:sticky lg:top-28"><p class="text-xs font-bold uppercase tracking-wider text-slate-400">Pratinjau profil</p><UserAvatar :name="previewName" :src="form.avatar" size="lg" class="mx-auto mt-5" /><h2 class="mt-4 truncate text-lg font-extrabold text-ink">{{ previewName }}</h2><p class="mt-1 truncate text-sm text-slate-500">{{ form.email || 'email@pengguna.com' }}</p></aside>
    </div>
  </section>
</template>
