<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRoute } from 'vue-router'

import UserAvatar from '@/components/UserAvatar.vue'
import { deleteUser as removeUser, getUsers } from '@/services/userApi'

const route = useRoute()
const users = ref([])
const searchQuery = ref('')
const isLoading = ref(true)
const errorMessage = ref('')
const deletingId = ref(null)
const actionError = ref('')
const showCreatedMessage = computed(() => route.query.created === '1')
const showUpdatedMessage = computed(() => route.query.updated === '1')

const filteredUsers = computed(() => {
  const query = searchQuery.value.trim().toLowerCase()

  if (!query) return users.value

  return users.value.filter(
    (user) =>
      user.name?.toLowerCase().includes(query) ||
      user.email?.toLowerCase().includes(query),
  )
})

async function fetchUsers() {
  isLoading.value = true
  errorMessage.value = ''

  try {
    const data = await getUsers()
    users.value = Array.isArray(data) ? data : []
  } catch (error) {
    errorMessage.value =
      'Data pengguna belum dapat dimuat. Periksa koneksi internet lalu coba lagi.'
    console.error(error)
  } finally {
    isLoading.value = false
  }
}

function editUser(id) {
  return { name: 'edit-user', params: { id } }
}

async function deleteUser(user) {
  if (!window.confirm(`Hapus pengguna “${user.name || 'Tanpa nama'}”?`)) return

  deletingId.value = user.id
  actionError.value = ''

  try {
    await removeUser(user.id)
    users.value = users.value.filter((item) => item.id !== user.id)
  } catch (error) {
    actionError.value = 'Pengguna gagal dihapus. Silakan coba lagi.'
    console.error(error)
  } finally {
    deletingId.value = null
  }
}

onMounted(fetchUsers)
</script>

<template>
  <section>
    <div
      v-if="actionError"
      class="mb-6 flex items-start gap-3 rounded-2xl border border-red-100 bg-red-50 p-4 text-sm text-red-700"
      role="alert"
    >
      <span>{{ actionError }}</span>
    </div>

    <div
      v-if="showCreatedMessage"
      class="mb-6 flex items-start gap-3 rounded-2xl border border-emerald-100 bg-emerald-50 p-4 text-sm text-emerald-800"
      role="status"
    >
      <svg
        class="mt-0.5 size-5 shrink-0"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        aria-hidden="true"
      >
        <path d="M20 6 9 17l-5-5" />
      </svg>
      <div>
        <p class="font-bold">Pengguna berhasil ditambahkan.</p>
        <p class="mt-0.5 text-emerald-700">Data terbaru sudah dimuat dari MockAPI.</p>
      </div>
    </div>

    <div
      v-if="showUpdatedMessage"
      class="mb-6 flex items-start gap-3 rounded-2xl border border-blue-100 bg-blue-50 p-4 text-sm text-blue-800"
      role="status"
    >
      <svg class="mt-0.5 size-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
        <path d="M20 6 9 17l-5-5" />
      </svg>
      <div>
        <p class="font-bold">Pengguna berhasil diperbarui.</p>
        <p class="mt-0.5 text-blue-700">Perubahan sudah disimpan ke MockAPI.</p>
      </div>
    </div>

    <div class="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end">
      <div>
        <div
          class="mb-3 inline-flex items-center gap-2 rounded-full bg-pink-50 px-3 py-1 text-xs font-bold uppercase tracking-wider text-pink-700"
        >
          <span class="size-1.5 rounded-full bg-pink-500"></span>
          Direktori aktif
        </div>
        <h1 class="text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">
          Daftar Pengguna
        </h1>
        <p class="mt-2 max-w-xl text-sm leading-6 text-slate-500 sm:text-base">
          Lihat dan temukan seluruh pengguna yang tersimpan di MockAPI.
        </p>
      </div>

      <RouterLink to="/users/add" class="btn-primary w-full md:w-auto">
        <svg
          class="size-5"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          aria-hidden="true"
        >
          <path d="M12 5v14M5 12h14" />
        </svg>
        Tambah pengguna
      </RouterLink>
    </div>

    <div class="page-card overflow-hidden">
      <div
        class="flex flex-col gap-4 border-b border-slate-100 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-6"
      >
        <div class="relative w-full sm:max-w-sm">
          <svg
            class="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-slate-400"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            aria-hidden="true"
          >
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.35-4.35" />
          </svg>
          <input
            v-model="searchQuery"
            type="search"
            class="form-input pl-11"
            placeholder="Cari nama atau email..."
            aria-label="Cari pengguna"
          />
        </div>

        <div class="flex items-center justify-between gap-3 sm:justify-end">
          <span class="text-sm font-semibold text-slate-500">
            {{ filteredUsers.length }} pengguna
          </span>
          <button
            type="button"
            class="btn-secondary !px-3 !py-2.5"
            :disabled="isLoading"
            aria-label="Muat ulang data"
            @click="fetchUsers"
          >
            <svg
              class="size-4"
              :class="{ 'animate-spin': isLoading }"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              aria-hidden="true"
            >
              <path d="M20 11a8.1 8.1 0 0 0-15.5-2M4 4v5h5M4 13a8.1 8.1 0 0 0 15.5 2M20 20v-5h-5" />
            </svg>
            <span class="sr-only sm:not-sr-only">Muat ulang</span>
          </button>
        </div>
      </div>

      <div v-if="isLoading" class="divide-y divide-slate-100" aria-live="polite">
        <div
          v-for="index in 5"
          :key="index"
          class="flex animate-pulse items-center gap-4 px-4 py-5 sm:px-6"
        >
          <div class="size-12 rounded-xl bg-slate-100"></div>
          <div class="flex-1">
            <div class="h-4 w-36 rounded bg-slate-100"></div>
            <div class="mt-2 h-3 w-52 max-w-full rounded bg-slate-100"></div>
          </div>
          <div class="hidden h-6 w-12 rounded-full bg-slate-100 sm:block"></div>
        </div>
      </div>

      <div v-else-if="errorMessage" class="px-5 py-16 text-center" role="alert">
        <div
          class="mx-auto grid size-14 place-items-center rounded-2xl bg-red-50 text-red-500"
        >
          <svg
            class="size-7"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            aria-hidden="true"
          >
            <circle cx="12" cy="12" r="10" />
            <path d="M12 8v4M12 16h.01" />
          </svg>
        </div>
        <h2 class="mt-4 text-lg font-bold text-ink">Terjadi kesalahan</h2>
        <p class="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-500">
          {{ errorMessage }}
        </p>
        <button type="button" class="btn-secondary mt-5" @click="fetchUsers">
          Coba lagi
        </button>
      </div>

      <div
        v-else-if="filteredUsers.length === 0"
        class="px-5 py-16 text-center"
        aria-live="polite"
      >
        <div
          class="mx-auto grid size-14 place-items-center rounded-2xl bg-slate-100 text-slate-400"
        >
          <svg
            class="size-7"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            aria-hidden="true"
          >
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.35-4.35" />
          </svg>
        </div>
        <h2 class="mt-4 text-lg font-bold text-ink">Pengguna tidak ditemukan</h2>
        <p class="mt-2 text-sm text-slate-500">
          Coba gunakan kata pencarian lain.
        </p>
      </div>

      <ul v-else class="divide-y divide-slate-100">
        <li
          v-for="(user, index) in filteredUsers"
          :key="user.id"
          class="group flex items-center gap-4 px-4 py-4 transition hover:bg-slate-50/80 sm:px-6 sm:py-5"
        >
          <UserAvatar :name="user.name" :src="user.avatar" />

          <div class="min-w-0 flex-1">
            <h2 class="truncate text-sm font-bold text-ink sm:text-base">
              {{ user.name || 'Tanpa nama' }}
            </h2>
            <a
              :href="`mailto:${user.email}`"
              class="focus-ring mt-1 inline-block max-w-full truncate rounded text-xs text-slate-500 transition hover:text-pink-700 sm:text-sm"
            >
              {{ user.email || 'Email tidak tersedia' }}
            </a>
          </div>

          <div class="hidden items-center gap-3 sm:flex">
            <span
              class="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-bold text-emerald-700"
            >
              Aktif
            </span>
            <span class="w-10 text-right text-xs font-semibold text-slate-300">
              #{{ String(user.id ?? index + 1).padStart(2, '0') }}
            </span>
          </div>

          <div class="flex items-center gap-1 opacity-100 sm:opacity-0 sm:transition sm:group-hover:opacity-100">
            <RouterLink
              :to="editUser(user.id)"
              class="focus-ring rounded-lg p-2 text-slate-400 transition hover:bg-blue-50 hover:text-blue-600"
              :aria-label="`Edit ${user.name || 'pengguna'}`"
              title="Edit pengguna"
            >
              <svg class="size-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <path d="M12 20h9" /><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4Z" />
              </svg>
            </RouterLink>
            <button
              type="button"
              class="focus-ring rounded-lg p-2 text-slate-400 transition hover:bg-red-50 hover:text-red-600 disabled:opacity-50"
              :aria-label="`Hapus ${user.name || 'pengguna'}`"
              title="Hapus pengguna"
              :disabled="deletingId === user.id"
              @click="deleteUser(user)"
            >
              <svg v-if="deletingId !== user.id" class="size-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
                <path d="M3 6h18M8 6V4h8v2m-9 0 1 15h8l1-15M10 11v6M14 11v6" />
              </svg>
              <span v-else class="block size-4 animate-spin rounded-full border-2 border-current border-t-transparent" aria-hidden="true"></span>
            </button>
          </div>
        </li>
      </ul>
    </div>
  </section>
</template>
