<script setup>
import { computed, reactive, ref } from "vue";
import { useRouter } from "vue-router";

import UserAvatar from "@/components/UserAvatar.vue";
import { createUser } from "@/services/userApi";

const router = useRouter();
const form = reactive({
  name: "",
  email: "",
  avatar: "",
});
const errors = reactive({});
const isSubmitting = ref(false);
const submitError = ref("");

const previewName = computed(() => form.name.trim() || "Nama pengguna");

function validateForm() {
  errors.name = "";
  errors.email = "";
  errors.avatar = "";

  if (!form.name.trim()) {
    errors.name = "Nama lengkap wajib diisi.";
  } else if (form.name.trim().length < 3) {
    errors.name = "Nama minimal terdiri dari 3 karakter.";
  }

  if (!form.email.trim()) {
    errors.email = "Alamat email wajib diisi.";
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
    errors.email = "Masukkan alamat email yang valid.";
  }

  if (form.avatar && !/^https?:\/\/.+/i.test(form.avatar)) {
    errors.avatar = "URL foto harus diawali dengan http:// atau https://.";
  }

  return !errors.name && !errors.email && !errors.avatar;
}

async function handleSubmit() {
  submitError.value = "";

  if (!validateForm()) return;

  isSubmitting.value = true;

  try {
    await createUser({
      name: form.name.trim(),
      email: form.email.trim().toLowerCase(),
      avatar: form.avatar.trim(),
    });

    await router.push({
      name: "users",
      query: { created: "1" },
    });
  } catch (error) {
    submitError.value =
      "Pengguna gagal disimpan. Periksa koneksi internet lalu coba kembali.";
    console.error(error);
  } finally {
    isSubmitting.value = false;
  }
}
</script>

<template>
  <section>
    <RouterLink
      to="/"
      class="focus-ring mb-6 inline-flex items-center gap-2 rounded-lg text-sm font-bold text-slate-500 transition hover:text-ink"
    >
      <svg
        class="size-4"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        aria-hidden="true"
      >
        <path d="m15 18-6-6 6-6" />
      </svg>
      Kembali ke daftar
    </RouterLink>

    <div class="grid gap-8 lg:grid-cols-[minmax(0,1fr)_340px] lg:items-start">
      <div>
        <div class="mb-8">
          <div
            class="mb-3 inline-flex items-center gap-2 rounded-full bg-pink-50 px-3 py-1 text-xs font-bold uppercase tracking-wider text-pink-700"
          >
            Data baru
          </div>
          <h1
            class="text-3xl font-extrabold tracking-tight text-ink sm:text-4xl"
          >
            Tambah Pengguna
          </h1>
          <p
            class="mt-2 max-w-xl text-sm leading-6 text-slate-500 sm:text-base"
          >
            Isi informasi berikut untuk menambahkan pengguna baru ke dalam
            sistem.
          </p>
        </div>

        <form
          class="page-card p-5 sm:p-8"
          novalidate
          @submit.prevent="handleSubmit"
        >
          <div
            v-if="submitError"
            class="mb-6 flex gap-3 rounded-xl border border-red-100 bg-red-50 p-4 text-sm text-red-700"
            role="alert"
          >
            <svg
              class="mt-0.5 size-5 shrink-0"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              aria-hidden="true"
            >
              <circle cx="12" cy="12" r="10" />
              <path d="M12 8v4M12 16h.01" />
            </svg>
            {{ submitError }}
          </div>

          <div class="grid gap-6">
            <div>
              <label for="name" class="mb-2 block text-sm font-bold text-ink">
                Nama lengkap <span class="text-red-500">*</span>
              </label>
              <input
                id="name"
                v-model="form.name"
                type="text"
                class="form-input"
                :class="{ '!border-red-300': errors.name }"
                placeholder="Contoh: Ananda Aulia"
                autocomplete="name"
                :aria-invalid="Boolean(errors.name)"
                :aria-describedby="errors.name ? 'name-error' : undefined"
                @input="errors.name = ''"
              />
              <p
                v-if="errors.name"
                id="name-error"
                class="mt-2 text-xs font-medium text-red-600"
              >
                {{ errors.name }}
              </p>
            </div>

            <div>
              <label for="email" class="mb-2 block text-sm font-bold text-ink">
                Alamat email <span class="text-red-500">*</span>
              </label>
              <input
                id="email"
                v-model="form.email"
                type="email"
                class="form-input"
                :class="{ '!border-red-300': errors.email }"
                placeholder="nama@email.com"
                autocomplete="email"
                :aria-invalid="Boolean(errors.email)"
                :aria-describedby="errors.email ? 'email-error' : undefined"
                @input="errors.email = ''"
              />
              <p
                v-if="errors.email"
                id="email-error"
                class="mt-2 text-xs font-medium text-red-600"
              >
                {{ errors.email }}
              </p>
            </div>

            <div>
              <div class="mb-2 flex items-center justify-between gap-3">
                <label for="avatar" class="block text-sm font-bold text-ink">
                  URL foto profil
                </label>
                <span class="text-xs font-medium text-slate-400">Opsional</span>
              </div>
              <input
                id="avatar"
                v-model="form.avatar"
                type="url"
                class="form-input"
                :class="{ '!border-red-300': errors.avatar }"
                placeholder="https://contoh.com/foto.jpg"
                autocomplete="url"
                :aria-invalid="Boolean(errors.avatar)"
                :aria-describedby="
                  errors.avatar ? 'avatar-error' : 'avatar-help'
                "
                @input="errors.avatar = ''"
              />
              <p
                v-if="errors.avatar"
                id="avatar-error"
                class="mt-2 text-xs font-medium text-red-600"
              >
                {{ errors.avatar }}
              </p>
              <p v-else id="avatar-help" class="mt-2 text-xs text-slate-400">
                Kosongkan jika tidak ingin menggunakan foto.
              </p>
            </div>
          </div>

          <div
            class="mt-8 flex flex-col-reverse gap-3 border-t border-slate-100 pt-6 sm:flex-row sm:justify-end"
          >
            <RouterLink to="/" class="btn-secondary">Batal</RouterLink>
            <button
              type="submit"
              class="btn-primary min-w-40"
              :disabled="isSubmitting"
            >
              <svg
                v-if="isSubmitting"
                class="size-5 animate-spin"
                viewBox="0 0 24 24"
                fill="none"
                aria-hidden="true"
              >
                <circle
                  class="opacity-25"
                  cx="12"
                  cy="12"
                  r="10"
                  stroke="currentColor"
                  stroke-width="4"
                />
                <path
                  class="opacity-75"
                  fill="currentColor"
                  d="M4 12a8 8 0 0 1 8-8v4a4 4 0 0 0-4 4H4Z"
                />
              </svg>
              <svg
                v-else
                class="size-5"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                aria-hidden="true"
              >
                <path
                  d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"
                />
                <path d="M17 21v-8H7v8M7 3v5h8" />
              </svg>
              {{ isSubmitting ? "Menyimpan..." : "Simpan pengguna" }}
            </button>
          </div>
        </form>
      </div>

      <aside class="page-card overflow-hidden lg:sticky lg:top-28">
        <div class="border-b border-slate-100 px-6 py-5">
          <p class="text-xs font-bold uppercase tracking-wider text-slate-400">
            Pratinjau profil
          </p>
        </div>
        <div class="p-6 text-center">
          <UserAvatar
            :name="previewName"
            :src="form.avatar"
            size="lg"
            class="mx-auto"
          />
          <h2 class="mt-4 truncate text-lg font-extrabold text-ink">
            {{ previewName }}
          </h2>
          <p class="mt-1 truncate text-sm text-slate-500">
            {{ form.email || "email@pengguna.com" }}
          </p>
          <span
            class="mt-5 inline-flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-bold text-emerald-700"
          >
            <span class="size-1.5 rounded-full bg-emerald-500"></span>
            Pengguna aktif
          </span>
        </div>
        <div
          class="bg-slate-50 px-6 py-4 text-center text-xs leading-5 text-slate-400"
        >
          Data akan disimpan secara langsung ke MockAPI.
        </div>
      </aside>
    </div>
  </section>
</template>
