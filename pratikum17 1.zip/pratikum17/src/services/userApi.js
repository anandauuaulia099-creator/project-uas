const API_URL =
  import.meta.env.VITE_API_URL ??
  'https://6a4a4060edfa6a2b5fd7b107.mockapi.io/users'

async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
    ...options,
  })

  if (!response.ok) {
    throw new Error(`Permintaan gagal dengan status ${response.status}`)
  }

  if (response.status === 204) return null

  return response.json()
}

export function getUsers() {
  return request(API_URL)
}

export function getUser(id) {
  return request(`${API_URL}/${encodeURIComponent(id)}`)
}

export function createUser(user) {
  return request(API_URL, {
    method: 'POST',
    body: JSON.stringify(user),
  })
}

export function updateUser(id, user) {
  return request(`${API_URL}/${encodeURIComponent(id)}`, {
    method: 'PUT',
    body: JSON.stringify(user),
  })
}

export function deleteUser(id) {
  return request(`${API_URL}/${encodeURIComponent(id)}`, {
    method: 'DELETE',
  })
}
