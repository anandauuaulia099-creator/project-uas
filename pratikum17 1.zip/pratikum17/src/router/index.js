import { createRouter, createWebHistory } from 'vue-router'

import AddUserView from '@/views/AddUserView.vue'
import EditUserView from '@/views/EditUserView.vue'
import UserListView from '@/views/UserListView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'users',
      component: UserListView,
      meta: { title: 'Daftar Pengguna' },
    },
    {
      path: '/users/add',
      name: 'add-user',
      component: AddUserView,
      meta: { title: 'Tambah Pengguna' },
    },
    {
      path: '/users/:id/edit',
      name: 'edit-user',
      component: EditUserView,
      meta: { title: 'Edit Pengguna' },
    },
    {
      path: '/:pathMatch(.*)*',
      redirect: '/',
    },
  ],
  scrollBehavior: () => ({ top: 0 }),
})

router.afterEach((to) => {
  document.title = `${to.meta.title ?? 'User Manager'} · User Manager`
})

export default router
