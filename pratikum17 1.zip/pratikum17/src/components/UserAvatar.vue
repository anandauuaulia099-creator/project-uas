<script setup>
import { computed, ref, watch } from 'vue'

const props = defineProps({
  name: {
    type: String,
    default: '',
  },
  src: {
    type: String,
    default: '',
  },
  size: {
    type: String,
    default: 'md',
  },
})

const failed = ref(false)
const showImage = computed(() => props.src && !failed.value)
const initials = computed(() => {
  const words = props.name.trim().split(/\s+/).filter(Boolean)

  if (!words.length) return '?'

  return words
    .slice(0, 2)
    .map((word) => word[0])
    .join('')
    .toUpperCase()
})

const sizeClass = computed(() =>
  props.size === 'lg' ? 'size-20 text-xl rounded-2xl' : 'size-12 text-sm rounded-xl',
)

watch(
  () => props.src,
  () => {
    failed.value = false
  },
)
</script>

<template>
  <div
    class="grid shrink-0 place-items-center overflow-hidden bg-gradient-to-br from-pink-100 to-pink-50 font-bold text-pink-700 ring-1 ring-inset ring-pink-100"
    :class="sizeClass"
  >
    <img
      v-if="showImage"
      :src="src"
      :alt="`Foto ${name}`"
      class="size-full object-cover"
      loading="lazy"
      @error="failed = true"
    />
    <span v-else aria-hidden="true">{{ initials }}</span>
  </div>
</template>
