<script setup>
const navItems = [
  {
    label: 'Daftar Pengguna',
    to: '/',
    icon: 'users',
  },
  {
    label: 'Tambah Pengguna',
    to: '/users/add',
    icon: 'plus',
  },
]
</script>

<template>
  <div class="min-h-screen">
    <header
      class="sticky top-0 z-40 border-b border-slate-200/80 bg-white/90 backdrop-blur-xl"
    >
      <div
        class="mx-auto flex h-[72px] max-w-7xl items-center justify-between gap-5 px-4 sm:px-6 lg:px-8"
      >
        <RouterLink to="/" class="focus-ring flex items-center gap-3 rounded-xl">
          <span
            class="grid size-10 place-items-center rounded-xl bg-pink-600 text-white shadow-lg shadow-pink-600/20"
          >
            <svg
              class="size-5"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              aria-hidden="true"
            >
              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M19 8v6M22 11h-6" />
            </svg>
          </span>
          <span>
            <span class="block font-display text-sm font-extrabold leading-tight text-ink sm:text-base">
              User Manager
            </span>
            <span class="hidden text-xs text-slate-400 sm:block">Kelola data pengguna</span>
          </span>
        </RouterLink>

        <nav class="flex items-center gap-1.5" aria-label="Navigasi utama">
          <RouterLink
            v-for="item in navItems"
            :key="item.to"
            :to="item.to"
            class="focus-ring inline-flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-500 transition hover:bg-slate-100 hover:text-ink sm:px-4"
            active-class="!bg-pink-50 !text-pink-700"
            :aria-label="item.label"
          >
            <svg
              v-if="item.icon === 'users'"
              class="size-5 shrink-0"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              aria-hidden="true"
            >
              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
            <svg
              v-else
              class="size-5 shrink-0"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              aria-hidden="true"
            >
              <path d="M12 5v14M5 12h14" />
            </svg>
            <span class="hidden sm:inline">{{ item.label }}</span>
          </RouterLink>
        </nav>
      </div>
    </header>

    <main class="mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-10 lg:px-8 lg:py-12">
      <slot />
    </main>

    <footer class="px-4 pb-8 text-center text-xs text-slate-400">
      User Manager · Vue 3 & MockAPI
    </footer>
  </div>
</template>
